
/*
 *
 * Smell code			:
 * potential cause(s)	:
 * solution(s)			:
 *
 */

public interface BangunDatar {
	public float computeArea();
	public float computeAround();
}
