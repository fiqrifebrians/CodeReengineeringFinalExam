
/*
 *
 * Smell code			:
 * potential cause(s)	:
 * solution(s)			:
 *
 */

public class BangunRuang implements BangunDatar {

	@Override
	public float computeArea() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float computeAround() {
		// TODO Auto-generated method stub
		return 0;
	}

	public float computeVolume() {
		return 0;
	}

}
