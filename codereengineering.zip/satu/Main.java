public class Main{
	public static void main(String [] args){
		Persegi persegi = new Persegi();
		persegi.sisi = 8;
		System.out.println(persegi.computeArea());
	}
}